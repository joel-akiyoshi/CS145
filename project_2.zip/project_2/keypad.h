/*
 * keypad.h
 *
 * Created: 4/26/2024 12:25:14 PM
 *  Author: Chan Young Ji & Joel Akiyoshi
 */ 

#ifndef _KEYPAD_H
#define _KEYPAD_H

int get_key(void);

int is_pressed(int r, int c);

#endif /* _LCD_H */